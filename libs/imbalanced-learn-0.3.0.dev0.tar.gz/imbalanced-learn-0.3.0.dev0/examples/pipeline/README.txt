.. _pipeline_examples:

Pipeline examples
=================

Example of how to use the a pipeline to include under-sampling with `scikit-learn` estimators.