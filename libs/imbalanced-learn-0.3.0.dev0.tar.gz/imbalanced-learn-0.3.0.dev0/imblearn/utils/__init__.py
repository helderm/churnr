"""
The :mod:`imblearn.utils` module includes various utilities.
"""

from .validation import check_neighbors_object


__all__ = ['check_neighbors_object']
