.. currentmodule:: imbalanced-learn

.. _todo_0_2:

==========
To Do list
==========

Version 0.2
-----------

New methods
~~~~~~~~~~~

* SMOTEBagging_: Wang, Shuo, and Xin Yao. "Diversity analysis on imbalanced data sets by using ensemble models." Computational Intelligence and Data Mining, 2009. CIDM'09. IEEE Symposium on. IEEE, 2009.

.. _SMOTEBagging: http://pages.bangor.ac.uk/~mas00a/papers/jpjrcolkis15.pdf

API improvements
~~~~~~~~~~~~~~~~

* Remove `npy` files in the testting and perform toy tests instead.
